package com.javatpoint.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatpoint.model.AddStudent;

public interface StudentRepository extends JpaRepository<AddStudent, Long>{

}
